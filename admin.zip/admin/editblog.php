<div class="modal fade" id="update<?php echo $fetch['blogid']?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update <?php echo $fetch['blogtitle']?> blog</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php">
                    <div class="form-group">
                        <label for="title" class="col-sm-1 control-label">Title</label>

                        <div class="col-sm-5">
                            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $fetch['blogid']?>" required>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo $fetch['blogtitle']?>" required>
                        </div>

                        <label for="category" class="col-sm-1 control-label">Category</label>


                        <div class="col-sm-5">
                            <select class="form-control" id="category" name="category"  required>
                                <option value="<?php echo $fetch['id']?>"><?php echo $fetch['name']?></option>
                                <?php

                                $result=mysqli_query($con,"select * from categories")or die ("query 1 incorrect.....");

                                while(list($id,$title,$name)=mysqli_fetch_array($result))
                                {
                                    echo "
                                    <option value='$id'>$name</option>
                                   ";
                                }
                                ?>

                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="info" class="col-sm-1 control-label">Info</label>

                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="info" name="info" value="<?php echo $fetch['info']?>" required>
                        </div>

                        <label for="photo" class="col-sm-1 control-label">Photo</label>

                        <div class="col-sm-5">
                            <input type="file" id="photo" name="photo">
                        </div>
                    </div>
                    <p><b>Description</b></p>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <textarea id="desc" name="desc" rows="10" cols="80"  required><?php echo $fetch['description']?>
                            </textarea>
                        </div>

                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="editblog"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="delete<?php echo $fetch['blogid']?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete <?php echo $fetch['blogtitle']?> Blog?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Are you sure you want to delete <?php echo $fetch['blogtitle']?> blog?</div>
            <div class="modal-footer">
                <form action="action.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $fetch['blogid']?>"/>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-danger" type="submit" name="deleteblog">Delete</button>
                </form>

            </div>
        </div>
    </div>
</div>