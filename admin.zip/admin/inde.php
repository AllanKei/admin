<?php
include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/nav.php';
include 'includes/modal.php';
include 'includes/scripts.php';