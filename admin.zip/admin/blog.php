<?php
include 'includes/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/nav.php';
include 'includes/modal.php';
include 'includes/scripts.php';

?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="container-fluid">
        <h3 class="mt-4 text-gray-600">Featured blogs</h3>
    </div>
    <br>
    <?php

    if(isset($_SESSION['error'])){
        echo "
          <div class='alert alert-danger text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['error']."</p> 
          </div>
        ";
        unset($_SESSION['error']);
    }

    if(isset($_SESSION['success'])){
        echo "
          <div class='alert alert-success text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['success']."</p> 
          </div>
        ";
        unset($_SESSION['success']);
    }
    ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Blogs</h6>
            <button class=" float-right"  data-toggle="modal" data-target="#new"><i class="fa fa-plus"></i> Add blog</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Category</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $query = mysqli_query($con, "SELECT *,b.id,b.name FROM blogs,categories b WHERE catid=b.id ");
                    while($fetch = mysqli_fetch_array($query)){
                        ?>
                        <tr>
                            <td><?php echo $fetch['blogid']?></td>
                            <td>Image</td>
                            <td><?php echo $fetch['name']?></td>
                            <td>
                                <h5 class='text-primary'><?php echo $fetch['blogtitle']?></h5>
                                <?php echo $fetch['info']?>
                            </td>
                            <td><?php echo $fetch['description']?></td>
                            <td><?php echo $fetch['date']?></td>
                            <td>
                                <a href=""  data-toggle="modal" type="button" data-target="#update<?php echo $fetch['blogid']?>" title="edit"><span class="fas fa-edit fa-lg text-success mr-2"></span></a>
                                <a href=""  data-toggle="modal" type="button" data-target="#delete<?php echo $fetch['blogid']?>" title="delete"><span class="fas fa-trash-alt fa-lg text-danger"></span></a>
                            </td>

                        </tr>

                        <?php

                        include 'editblog.php';


                    }
                    exit();
                    ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php
