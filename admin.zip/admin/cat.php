<?php
include 'includes/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/nav.php';

include 'includes/modal.php';
include 'includes/scripts.php';
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="container-fluid">
        <h3 class="mt-4 text-gray-600">Featured categories</h3>
    </div>
    <br>
    <?php

    if(isset($_SESSION['error'])){
        echo "
          <div class='alert alert-danger text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['error']."</p> 
          </div>
        ";
        unset($_SESSION['error']);
    }

    if(isset($_SESSION['success'])){
        echo "
          <div class='alert alert-success text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['success']."</p> 
          </div>
        ";
        unset($_SESSION['success']);
    }
    ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Categories</h6>
            <button class=" float-right" data-toggle="modal" data-target="#cat"><i class="fa fa-plus"></i> Add category</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>id</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Title</th>
                        <th>Action</th>
                    </tr>
                    </thead>

                    <?php
                    $query = mysqli_query($con, "SELECT * FROM `categories`") or die(mysqli_error());
                    while($fetch = mysqli_fetch_array($query)){
                        ?>
                        <tr>
                            <td><?php echo $fetch['id']?></td>
                            <td>image</td>
                            <td><?php echo $fetch['name']?></td>
                            <td><?php echo $fetch['title']?></td>
                            <td>
                                <a href=""  data-toggle="modal" type="button" data-target="#update_modal<?php echo $fetch['id']?>" title="edit"><span class="fas fa-edit fa-lg text-success mr-2"></span></a>
                                <a href=""  data-toggle="modal" type="button" data-target="#delete_modal<?php echo $fetch['id']?>" title="delete"><span class="fas fa-trash-alt fa-lg text-danger"></span></a>
                            </td>
                        </tr>
                        <?php

                        include 'editcategory.php';


                    }
                    exit();
                    ?>

                </table>
            </div>
        </div>
    </div>

</div>



