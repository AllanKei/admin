<?php

session_start();

include 'includes/db.php';

//admin registration

if (isset($_POST['register'])){

    $first=$_POST['firstname'];
    $last=$_POST['lastname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $repassword=$_POST['repassword'];

    $date = date('Y-m-d');

    if(empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword)){
        $_SESSION['error'] = 'Please fill in the form';
        header('location: sign.php');

    } else {
        if(strlen($password) < 8 ){
            $_SESSION['error'] = 'Password is weak';
            header('location: sign.php');
            exit;
        }
        if($password != $repassword){
            $_SESSION['error']= 'Passwords dont match';
            header('location: sign.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT id FROM users WHERE email = '$email' LIMIT 1" ;
        $check_query = mysqli_query($con,$sql);
        $count_email = mysqli_num_rows($check_query);
        if($count_email > 0){
            $_SESSION['error']='Email already exists, <a href="login.php">login</a> instead';
            header('location:sign.php');

        } else {

            $sql = "INSERT INTO `users` 
		(`id`, `fname`, `lname`, `email`, 
		`password`,`created_at`) 
		VALUES (NULL, '$first', '$last', '$email', 
		'$password','$date')";
            $run_query = mysqli_query($con,$sql);
            $_SESSION["uid"] = mysqli_insert_id($con);
            $_SESSION["name"] = $first;

            $ip_add = getenv("REMOTE_ADDR");
            if(mysqli_query($con,$sql)){
                echo "register_success";
                header('location: login.php');
                exit;
            }
        }
    }

}

//login action

if (isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $run_query = mysqli_query($con,$sql);
    $count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
    $_SESSION["uid"] = $row["id"];
    $_SESSION["name"] = $row["fname"];

    if(empty($email) || empty($password)){
        $_SESSION['error'] = 'Fill in the form first';
        header('location:login.php');
    }else{
        if ($count == 1){
            echo "login success";
            header('location: index.php');
        }
        else{
            $_SESSION['error'] = 'Incorrect login credentials';
            header('location:login.php');
        }
    }

}

//logout

if (isset($_POST['logout'])){
    unset($_SESSION['uid']);
    unset($_SESSION['name']);

    header('location:login.php');
}

//edit profile

if (isset($_POST['editprof'])){
    $first=$_POST['fname'];
    $last=$_POST['lname'];
    $email=$_POST['email'];
    $contact=$_POST['contact'];
    $address=$_POST['address'];

    $user = $_SESSION{"uid"};
    $sql ="UPDATE users SET fname='$first', lname='$last', email='$email', contact='$contact', address='$address' WHERE id= '$user'";

    $query=mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Profile updated successfully';
        header('location:profile.php');
    }
    else{
        $_SESSION['error']='profile not updated';
        header('location:profile.php');
    }
}

//edit photo

//edit password

//add category

if (isset($_POST['addcat'])){
    $name =$_POST['name'];
    $title=$_POST['title'];


    $sql = "INSERT INTO `categories` (`id`, `title`, `name`) VALUES (NULL, '$title', '$name')";
    $query =mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Category added successfully';
        header('location:cat.php');
    }
    else{
        $_SESSION['error']='Category not added';
        header('location:cat.php');
    }

}
//edit category

if (isset($_POST['editcat'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $title = $_POST['title'];
    $sql = "UPDATE `categories` SET `name` = '$name', `title` = '$title' WHERE `id` = '$id'" or die(mysqli_error());
    $query=mysqli_query($con, $sql);

    if ($query){
        $_SESSION['success']="$name category is updated succesfully";
        header('location:cat.php');
    }
    else{
        $_SESSION['error']="$name category not updated";
        header('location:cat.php');
    }
}
//delete category
if (isset($_POST['deletecat'])){
    $id= $_POST['id'];

    $sql="delete from categories where id='$id'" or die("query is incorrect...");
    $query= mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Category deleted successfully';
        header('location:cat.php');
    }
    else{
        $_SESSION['error']='Category not deleted';
        header('location:cat.php');
    }
}

//add blog

if (isset($_POST['addblog'])){

    $title= $_POST['title'];
    $category= $_POST['category'];
    $info= $_POST['info'];
    $desc= $_POST['desc'];

    $now= date('Y-m-d');

    $sql = "INSERT INTO `blogs` (`blogid`, `blogtitle`, `description`,`info`,`catid`,`date`) 
        VALUES (NULL, '$title', '$desc','$info','$category','$now')";

    $query =mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Blog added successfully';
        header('location:blog.php');
    }
    else{
        $_SESSION['error']='Blog not added';
        header('location:blog.php');
    }

}
//edit blog
if (isset($_POST['editblog'])){
    $id = $_POST['id'];
    $title= $_POST['title'];
    $category= $_POST['category'];
    $info= $_POST['info'];
    $desc= $_POST['desc'];

    $now= date('Y-m-d');
    $sql = "UPDATE `blogs` SET `blogtitle` = '$title', `description` = '$desc', `info` = '$info', `catid` = '$category', `date` = '$now' WHERE `blogid` = '$id'" or die(mysqli_error());

    $query =mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Blog updated successfully';
        header('location:blog.php');
    }
    else{
        $_SESSION['error']='Blog not updated';
        header('location:blog.php');
    }
}
//delete category
if (isset($_POST['deleteblog'])){
    $id= $_POST['id'];

    $sql="delete from blogs where blogid='$id'" or die("query is incorrect...");
    $query= mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Blog deleted successfully';
        header('location:blog.php');
    }
    else{
        $_SESSION['error']='Blog not deleted';
        header('location:blog.php');
    }
}