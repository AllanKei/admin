<?php
include 'includes/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/nav.php';
?>
    <div class="container-fluid">
    <div class="container-fluid">
        <h3 class="mt-4 text-gray-600">Featured categories</h3>
    </div>

    <div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Categories</h6>
        <button class=" float-right" data-toggle="modal" data-target="#cat"><i class="fa fa-plus"></i> Add category</button>
    </div>
    <div class="card-body">
    <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
            <tr>
                <th>id</th>
                <th>Image</th>
                <th>Name</th>
                <th>Title</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $query = mysqli_query($con, "SELECT * FROM `categories`") or die(mysqli_error());
            while($fetch = mysqli_fetch_array($query)){
                ?>
                <tr>
                    <td><?php echo $fetch['id']?></td>
                    <td><?php echo $fetch['name']?></td>
                    <td><?php echo $fetch['title']?></td>
                    <td><button class="btn btn-warning" data-toggle="modal" type="button" data-target="#update_modal<?php echo $fetch['id']?>"><span class="glyphicon glyphicon-edit"></span> Edit</button></td>
                </tr>
                <?php

                include 'editcategory.php';

            }
            ?>
            </tbody>
        </table>
    </div>
    </div>
    </div>
    </div>

<?php
include 'includes/modal.php';
include 'includes/scripts.php';