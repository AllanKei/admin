
<div class="modal fade" id="update_modal<?php echo $fetch['id']?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="action.php">
                <div class="modal-header">
                    <h3 class="modal-title">Update <?php echo $fetch['name']?> category</h3>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Firstname</label>
                            <input type="hidden" name="id" value="<?php echo $fetch['id']?>"/>
                            <input type="text" name="name" value="<?php echo $fetch['name']?>" class="form-control" required="required"/>
                        </div>
                        <div class="form-group">
                            <label>Lastname</label>
                            <input type="text" name="title" value="<?php echo $fetch['title']?>" class="form-control" required="required" />
                        </div>
                    </div>
                </div>
                <div style="clear:both;"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                    <button type="submit" class="btn btn-primary btn-flat" name="editcat"><i class="fa fa-save"></i> Edit</button>
                </div>
        </div>
        </form>
    </div>
</div>
</div>

<div class="modal fade" id="delete_modal<?php echo $fetch['id']?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete <?php echo $fetch['name']?> Category?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Are you sure you want to delete <?php echo $fetch['name']?> category?</div>
            <div class="modal-footer">
                <form action="action.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $fetch['id']?>"/>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-danger" type="submit" name="deletecat">Delete</button>
                </form>

            </div>
        </div>
    </div>
</div>