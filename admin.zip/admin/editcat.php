<?php

session_start();
include("includes/db.php");
$cid=$_REQUEST['id'];

$res=mysqli_query($con,"select id,name,title from categories where id='$cid'")or die ("query 1 incorrect.......");

list($id,$catname,$cattitle)=mysqli_fetch_array($res);

if(isset($_POST['btn_save']))
{

    $first_name=$_POST['first_name'];
    $last_name=$_POST['last_name'];
    $email=$_POST['email'];
    $user_password=$_POST['password'];

    mysqli_query($con,"update user_info set first_name='$first_name', last_name='$last_name', email='$email', password='$user_password' where user_id='$user_id'")or die("Query 2 is inncorrect..........");

    header("location: manageuser.php");
    mysqli_close($con);
}
?>


<!--edit cat-->
<div class="modal fade" id="editcat2">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit category</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>

                </div>
                <div class="modal-body">
                    <form class="form-horizontal" method="POST" action="action.php" id="ModalForm">

                        <input type="hidden" id="editId" value="<?php echo $cid;?>">
                        <div class="form-group">
                            <label for="name" class="col-sm-3 control-label">Name</label>

                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="editName" name="name" value="<?php echo $catname;?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name" class="col-sm-3 control-label">Title</label>

                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="editTitle" name="title" value="<?php echo $cattitle?>">
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                    <button type="submit" class="btn btn-primary btn-flat" name="editcat"><i class="fa fa-save"></i> Edit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

