<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="vendor/datatables/datatables-demo.js"></script>

<!-- Menu Toggle Script -->
<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    //cat
    $(function() {
        //Take the data from the TR during the event button
        $('table').on('click', 'button.editingTRbutton',function (ele) {
            //the <tr> variable is use to set the parentNode from "ele
            var tr = ele.target.parentNode.parentNode;

            //I get the value from the cells (td) using the parentNode (var tr)
            var id = tr.cells[0].textContent;
            var image = tr.cells[1].textContent;
            var name = tr.cells[2].textContent;
            var title = tr.cells[3].textContent;

            //Prefill the fields with the gathered information
            $('h5.modal-title').html('Edit category: '+name);
            $('#editName').val(name);
            $('#editTitle').val(title);

            //If you need to update the form data and change the button link
            $("form#ModalForm").attr('action', window.location.href+'/update/'+id);
            $("a#saveModalButton").attr('href', window.location.href+'/update/'+id);
        });
    });
</script>

</body>

</html>
