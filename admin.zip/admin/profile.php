<?php
include 'includes/db.php';
include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/nav.php';

?>

<!--profile content-->
<div class="container-fluid">
    <h3 class="mt-4 text-gray-600">Profile</h3>
</div>
<br>
<?php
$user = $_SESSION['uid'];
$sql = "SELECT * FROM users WHERE id ='$user'";
$query = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($query);

if(isset($_SESSION['error'])){
    echo "
          <div class='alert alert-danger text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['error']."</p> 
          </div>
        ";
    unset($_SESSION['error']);
}

if(isset($_SESSION['success'])){
    echo "
          <div class='alert alert-success text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['success']."</p> 
          </div>
        ";
    unset($_SESSION['success']);
}
?>
<div class="row">

    <!-- Photo -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <img src="img/1.jpg" style="width: 200px; height: 150px;">
                <button class="pof " data-toggle="modal" data-target="#pic"><i class="fa fa-edit"></i> Edit photo</button>
            </div>
        </div>
    </div>
    <!-- Profile info -->
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3 prof">
                <h6 class="m-0 font-weight-bold text-primary">Profile info</h6>
                <button class=" pof float-right"  data-toggle="modal" data-target="#profile"><i class="fa fa-edit"></i> Edit profile</button>
            </div>
            <div class="card-body">
                <h4 class="small font-weight-bold">Name: </h4>
                <p><?php echo $row['fname'],' ',$row['lname']?></p>
                <h4 class="small font-weight-bold">Email: </h4>
                <p><?php echo $row['email']?></p>
                <h4 class="small font-weight-bold">Contact: </h4>
                <p><?php echo $row['contact']?></p>
                <h4 class="small font-weight-bold">Address: </h4>
                <p><?php echo $row['address']?></p>

            </div>
        </div>
    </div>
</div>

<?php
include 'includes/modal.php';
include 'includes/scripts.php';
