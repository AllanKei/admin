<?php
session_start();

include 'includes/header.php';
?>

<div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

        <div class="col-xl-5 col-lg-6 col-md-9">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                </div>
                                <?php
                                if(isset($_SESSION['error'])){
                                    echo "
                                          <div class='alert alert-danger text-center'>
                                          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                            <p>".$_SESSION['error']."</p> 
                                          </div>
                                        ";
                                    unset($_SESSION['error']);
                                }

                                if(isset($_SESSION['success'])){
                                    echo "
                                          <div class='alert alert-success text-center'>
                                          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                            <p>".$_SESSION['success']."</p> 
                                          </div>
                                        ";
                                    unset($_SESSION['success']);
                                }
                                ?>
                                <form class="user" action="action.php" method="post">
                                    <div class="form-group">
                                        <input type="email" class="form-control form-control-user" name="email" id="Email" aria-describedby="emailHelp" placeholder="Enter Email Address...">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-user" name="password" id="Password" placeholder="Password">
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox small">
                                            <input type="checkbox" class="custom-control-input" id="customCheck">
                                            <label class="custom-control-label" for="customCheck">Remember Me</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary btn-user btn-block" name="login" value="Login">
                                    </div>
                                    <hr>
                                    <a href="" class="btn btn-google btn-user btn-block">
                                        <i class="fab fa-google fa-fw"></i> Login with Google
                                    </a>
                                    <a href="" class="btn btn-facebook btn-user btn-block">
                                        <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
                                    </a>
                                </form>
                                <hr>
                                <div class="text-center">
                                    <a class="small" href="">Forgot Password?</a>
                                </div>
                                <div class="text-center">
                                    <a class="small" href="sign.php">Create an Account!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>

<?php
include 'includes/scripts.php';
